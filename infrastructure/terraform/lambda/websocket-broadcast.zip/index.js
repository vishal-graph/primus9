// Broadcast Lambda - Called by backend/worker to push updates to users
const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, QueryCommand } = require('@aws-sdk/lib-dynamodb');
const { ApiGatewayManagementApiClient, PostToConnectionCommand, DeleteConnectionCommand } = require('@aws-sdk/client-apigatewaymanagementapi');

const client = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(client);
const TABLE_NAME = process.env.CONNECTIONS_TABLE;
const WEBSOCKET_ENDPOINT = process.env.WEBSOCKET_ENDPOINT;

exports.handler = async (event) => {
  console.log('Broadcast event:', JSON.stringify(event));
  
  // Support both direct invocation and API Gateway
  let body;
  if (event.body) {
    body = JSON.parse(event.body);
  } else {
    body = event;
  }
  
  const { userId, message } = body;
  
  if (!userId || !message) {
    return {
      statusCode: 400,
      body: JSON.stringify({ error: 'userId and message required' })
    };
  }
  
  // Find all connections for this user
  const connections = await docClient.send(new QueryCommand({
    TableName: TABLE_NAME,
    IndexName: 'userId-index',
    KeyConditionExpression: 'userId = :userId',
    ExpressionAttributeValues: { ':userId': userId }
  }));
  
  if (!connections.Items || connections.Items.length === 0) {
    console.log('No connections found for user:', userId);
    return {
      statusCode: 200,
      body: JSON.stringify({ sent: 0 })
    };
  }
  
  // Create API Gateway Management client
  const apigw = new ApiGatewayManagementApiClient({
    endpoint: WEBSOCKET_ENDPOINT
  });
  
  const messageData = JSON.stringify(message);
  let sentCount = 0;
  
  // Send to all connections
  for (const conn of connections.Items) {
    try {
      await apigw.send(new PostToConnectionCommand({
        ConnectionId: conn.connectionId,
        Data: messageData
      }));
      sentCount++;
      console.log('Message sent to connection:', conn.connectionId);
    } catch (error) {
      if (error.statusCode === 410) {
        // Connection is stale, remove it
        console.log('Removing stale connection:', conn.connectionId);
        await docClient.send(new DeleteCommand({
          TableName: TABLE_NAME,
          Key: { connectionId: conn.connectionId }
        }));
      } else {
        console.error('Error sending to connection:', conn.connectionId, error);
      }
    }
  }
  
  return {
    statusCode: 200,
    body: JSON.stringify({ sent: sentCount })
  };
};
