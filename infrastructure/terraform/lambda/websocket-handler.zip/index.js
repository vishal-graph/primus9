// WebSocket Connection Handlers for TatvaOps Vision
const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, PutCommand, DeleteCommand, QueryCommand } = require('@aws-sdk/lib-dynamodb');
const { ApiGatewayManagementApiClient, PostToConnectionCommand } = require('@aws-sdk/client-apigatewaymanagementapi');

const client = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(client);
const TABLE_NAME = process.env.CONNECTIONS_TABLE;

exports.handler = async (event) => {
  const connectionId = event.requestContext.connectionId;
  const routeKey = event.requestContext.routeKey;
  
  console.log('WebSocket event:', { routeKey, connectionId });
  
  try {
    switch (routeKey) {
      case '$connect':
        return await handleConnect(event, connectionId);
      case '$disconnect':
        return await handleDisconnect(connectionId);
      case '$default':
        return await handleDefault(event, connectionId);
      default:
        return { statusCode: 400, body: 'Unknown route' };
    }
  } catch (error) {
    console.error('WebSocket error:', error);
    return { statusCode: 500, body: 'Internal server error' };
  }
};

async function handleConnect(event, connectionId) {
  // Extract userId from query string (e.g., ?userId=xxx)
  const userId = event.queryStringParameters?.userId;
  
  if (!userId) {
    console.log('Connection rejected: No userId provided');
    return { statusCode: 401, body: 'userId required' };
  }
  
  // Store connection in DynamoDB
  const ttl = Math.floor(Date.now() / 1000) + 86400; // 24 hour TTL
  
  await docClient.send(new PutCommand({
    TableName: TABLE_NAME,
    Item: {
      connectionId,
      userId,
      connectedAt: new Date().toISOString(),
      ttl
    }
  }));
  
  console.log('Connection stored:', { connectionId, userId });
  return { statusCode: 200, body: 'Connected' };
}

async function handleDisconnect(connectionId) {
  // Remove connection from DynamoDB
  await docClient.send(new DeleteCommand({
    TableName: TABLE_NAME,
    Key: { connectionId }
  }));
  
  console.log('Connection removed:', connectionId);
  return { statusCode: 200, body: 'Disconnected' };
}

async function handleDefault(event, connectionId) {
  // Echo back any messages (for testing)
  const body = JSON.parse(event.body || '{}');
  console.log('Default message received:', body);
  
  return { statusCode: 200, body: JSON.stringify({ received: true }) };
}
